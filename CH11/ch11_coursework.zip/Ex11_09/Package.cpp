// Member-function definitions of class Package.
#include <stdexcept>
#include "Package.h" // Package class definition
using namespace std;

