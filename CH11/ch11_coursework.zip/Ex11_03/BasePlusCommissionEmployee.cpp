// Member-function definitions of class BasePlusCommissionEmployee 
// using composition.
#include <iostream>
#include <stdexcept>

// BasePlusCommissionEmployee class definition
#include "BasePlusCommissionEmployee.h"
using namespace std;

